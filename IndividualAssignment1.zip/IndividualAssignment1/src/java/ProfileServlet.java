import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ProfileServlet")
public class ProfileServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Step 1: Create ProfileBean object with form input data
        ProfileBean profile = new ProfileBean();
        profile.setName(request.getParameter("name"));
        profile.setStudentId(request.getParameter("studentId"));
        profile.setProgram(request.getParameter("program"));
        profile.setEmail(request.getParameter("email"));
        profile.setHobbies(request.getParameter("hobbies"));
        profile.setIntroduction(request.getParameter("introduction"));
        
        // Step 2: Insert profile data into database using JDBC
        Connection conn = null;
        PreparedStatement ps = null;
        
        try {
            // Load database driver
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            
            // Connect to database
            conn = DriverManager.getConnection(
                "jdbc:derby://localhost:1527/studentprofiles", 
                "dbuser", 
                "dbpass"
            );
            
            // Insert profile data into profiles table
            String sql = "INSERT INTO profile (name, student_id, program, email, hobbies, introduction) " +
                         "VALUES (?, ?, ?, ?, ?, ?)";
            ps = conn.prepareStatement(sql);
            ps.setString(1, profile.getName());
            ps.setString(2, profile.getStudentId());
            ps.setString(3, profile.getProgram());
            ps.setString(4, profile.getEmail());
            ps.setString(5, profile.getHobbies());
            ps.setString(6, profile.getIntroduction());
            
            // Execute insert
            ps.executeUpdate();
            
            // Step 3: Forward to display page
            request.setAttribute("name", profile.getName());
            request.setAttribute("studentId", profile.getStudentId());
            request.setAttribute("program", profile.getProgram());
            request.setAttribute("email", profile.getEmail());
            request.setAttribute("hobbies", profile.getHobbies());
            request.setAttribute("introduction", profile.getIntroduction());
            
            request.getRequestDispatcher("profile.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("<h2>Error: " + e.getMessage() + "</h2>");
            response.getWriter().println("<a href='index.html'>Go Back</a>");
        } finally {
            // Close resources
            try {
                if (ps != null) ps.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("index.html");
    }
}