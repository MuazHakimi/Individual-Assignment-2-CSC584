import java.io.Serializable;
import java.sql.Timestamp;

/**
 * JavaBean class to represent student profile data.
 * This class follows the JavaBean conventions with:
 * - Private attributes
 * - Public no-argument constructor
 * - Public getters and setters
 * - Implements Serializable
 */
public class ProfileBean implements Serializable {
    
    // Private attributes
    private int id;
    private String name;
    private String studentId;
    private String program;
    private String email;
    private String hobbies;
    private String introduction;
    private Timestamp createdDate;
    
    /**
     * No-argument constructor (required for JavaBean)
     */
    public ProfileBean() {
    }
    
    /**
     * Parameterized constructor for convenience
     */
    public ProfileBean(String name, String studentId, String program, 
                      String email, String hobbies, String introduction) {
        this.name = name;
        this.studentId = studentId;
        this.program = program;
        this.email = email;
        this.hobbies = hobbies;
        this.introduction = introduction;
    }
    
    /**
     * Full constructor including ID and timestamp
     */
    public ProfileBean(int id, String name, String studentId, String program, 
                      String email, String hobbies, String introduction, 
                      Timestamp createdDate) {
        this.id = id;
        this.name = name;
        this.studentId = studentId;
        this.program = program;
        this.email = email;
        this.hobbies = hobbies;
        this.introduction = introduction;
        this.createdDate = createdDate;
    }
    
    // Getters and Setters
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getStudentId() {
        return studentId;
    }
    
    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }
    
    public String getProgram() {
        return program;
    }
    
    public void setProgram(String program) {
        this.program = program;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getHobbies() {
        return hobbies;
    }
    
    public void setHobbies(String hobbies) {
        this.hobbies = hobbies;
    }
    
    public String getIntroduction() {
        return introduction;
    }
    
    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }
    
    public Timestamp getCreatedDate() {
        return createdDate;
    }
    
    public void setCreatedDate(Timestamp createdDate) {
        this.createdDate = createdDate;
    }
    
    /**
     * Validates if the profile has all required fields
     * @return true if all required fields are present
     */
    public boolean isValid() {
        return name != null && !name.trim().isEmpty() &&
               studentId != null && !studentId.trim().isEmpty() &&
               program != null && !program.trim().isEmpty() &&
               email != null && !email.trim().isEmpty();
    }
    
    /**
     * Returns a string representation of the ProfileBean
     * @return String containing profile information
     */
    @Override
    public String toString() {
        return "ProfileBean{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", studentId='" + studentId + '\'' +
                ", program='" + program + '\'' +
                ", email='" + email + '\'' +
                ", hobbies='" + hobbies + '\'' +
                ", introduction='" + introduction + '\'' +
                ", createdDate=" + createdDate +
                '}';
    }
}