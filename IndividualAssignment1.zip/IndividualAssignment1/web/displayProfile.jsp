<%@page import="java.sql.*"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    // Get profile data either from request attributes or database
    String name = "", studentId = "", program = "", email = "", hobbies = "", introduction = "";
    
    // Check if data is coming from form submission (request attributes)
    if (request.getAttribute("name") != null) {
        name = (String) request.getAttribute("name");
        studentId = (String) request.getAttribute("studentId");
        program = (String) request.getAttribute("program");
        email = (String) request.getAttribute("email");
        hobbies = (String) request.getAttribute("hobbies");
        introduction = (String) request.getAttribute("introduction");
    } 
    // Otherwise, fetch from database using ID parameter
    else if (request.getParameter("id") != null) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection(
                "jdbc:derby://localhost:1527/studentprofiles", 
                "dbuser", 
                "dbpass"
            );
            
            String sql = "SELECT * FROM profile WHERE id = ?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                name = rs.getString("name");
                studentId = rs.getString("student_id");
                program = rs.getString("program");
                email = rs.getString("email");
                hobbies = rs.getString("hobbies");
                introduction = rs.getString("introduction");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (conn != null) conn.close();
        }
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Profile - <%= name %></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Consolas', 'Courier New', monospace;
            background: #e8e8e8;
            color: #1a1a1a;
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
            border: 1px solid #ccc;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .header {
            background: #1a1a1a;
            color: #fff;
            padding: 30px;
            text-align: center;
            border-bottom: 2px solid #000;
        }
        .avatar {
            width: 80px;
            height: 80px;
            background: #fff;
            color: #1a1a1a;
            border: 2px solid #fff;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            font-weight: bold;
            margin-bottom: 15px;
        }
        h1 {
            font-size: 20px;
            margin: 10px 0;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        .student-id {
            font-size: 12px;
            letter-spacing: 1px;
            color: #ccc;
            text-transform: uppercase;
        }
        .success {
            background: #f5f5f5;
            color: #1a1a1a;
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #ddd;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .content {
            padding: 30px;
        }
        .info-box {
            background: #fafafa;
            padding: 15px;
            margin-bottom: 15px;
            border-left: 3px solid #1a1a1a;
        }
        .label {
            color: #666;
            font-size: 11px;
            text-transform: uppercase;
            margin-bottom: 5px;
            letter-spacing: 1px;
        }
        .value {
            color: #1a1a1a;
            font-size: 14px;
        }
        .intro-box {
            background: #f5f5f5;
            padding: 20px;
            margin-top: 20px;
            border: 1px solid #ddd;
        }
        .buttons {
            text-align: center;
            padding: 20px;
            background: #fafafa;
            border-top: 1px solid #ddd;
        }
        .btn {
            background: #1a1a1a;
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            display: inline-block;
            margin: 5px;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            border: none;
        }
        .btn:hover {
            background: #333;
        }
        .btn-secondary {
            background: #fff;
            color: #1a1a1a;
            border: 1px solid #1a1a1a;
        }
        .btn-secondary:hover {
            background: #f5f5f5;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="avatar">
                <%= name != null && !name.isEmpty() ? name.substring(0, 1).toUpperCase() : "?" %>
            </div>
            <h1><%= name != null ? name : "N/A" %></h1>
            <div class="student-id">ID: <%= studentId != null ? studentId : "N/A" %></div>
        </div>

        <% if (request.getAttribute("name") != null) { %>
        <div class="success">✓ PROFILE SAVED SUCCESSFULLY</div>
        <% } %>

        <div class="content">
            <div class="info-box">
                <div class="label">Program</div>
                <div class="value">
                    <%= program != null ? program : "N/A" %>
                </div>
            </div>

            <div class="info-box">
                <div class="label">Email</div>
                <div class="value">
                    <%= email != null ? email : "N/A" %>
                </div>
            </div>

            <div class="info-box">
                <div class="label">Hobbies</div>
                <div class="value">
                    <%= hobbies != null && !hobbies.isEmpty() ? hobbies : "Not specified" %>
                </div>
            </div>

            <% 
                if (introduction != null && !introduction.trim().isEmpty()) {
            %>
            <div class="intro-box">
                <div class="label">About Me</div>
                <div class="value"><%= introduction %></div>
            </div>
            <% } %>
        </div>

        <div class="buttons">
            <a href="index.html" class="btn">Add New Profile</a>
            <a href="viewProfiles.jsp" class="btn btn-secondary">View All Profiles</a>
        </div>
    </div>
</body>
</html>