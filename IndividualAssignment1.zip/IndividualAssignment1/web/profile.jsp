<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Profile - <%= request.getAttribute("name") %></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Consolas', 'Courier New', monospace;
            background: #e8e8e8;
            color: #1a1a1a;
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
            border: 1px solid #ccc;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .header {
            background: #1a1a1a;
            color: #fff;
            padding: 30px;
            text-align: center;
            border-bottom: 2px solid #000;
        }
        .avatar {
            width: 80px;
            height: 80px;
            background: #fff;
            color: #1a1a1a;
            border: 2px solid #fff;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            font-weight: bold;
            margin-bottom: 15px;
        }
        h1 {
            font-size: 20px;
            margin: 10px 0;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        .student-id {
            font-size: 12px;
            letter-spacing: 1px;
            color: #ccc;
            text-transform: uppercase;
        }
        .success {
            background: #f5f5f5;
            color: #1a1a1a;
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #ddd;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .content {
            padding: 30px;
        }
        .info-box {
            background: #fafafa;
            padding: 15px;
            margin-bottom: 15px;
            border-left: 3px solid #1a1a1a;
        }
        .label {
            color: #666;
            font-size: 11px;
            text-transform: uppercase;
            margin-bottom: 5px;
            letter-spacing: 1px;
        }
        .value {
            color: #1a1a1a;
            font-size: 14px;
        }
        .intro-box {
            background: #f5f5f5;
            padding: 20px;
            margin-top: 20px;
            border: 1px solid #ddd;
        }
        .buttons {
            text-align: center;
            padding: 20px;
            background: #fafafa;
            border-top: 1px solid #ddd;
        }
        .btn {
            background: #1a1a1a;
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            display: inline-block;
            margin: 5px;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            border: none;
        }
        .btn:hover {
            background: #333;
        }
        .btn-secondary {
            background: #fff;
            color: #1a1a1a;
            border: 1px solid #1a1a1a;
        }
        .btn-secondary:hover {
            background: #f5f5f5;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="avatar">
                <%= request.getAttribute("name").toString().substring(0, 1).toUpperCase() %>
            </div>
            <h1><%= request.getAttribute("name") %></h1>
            <div class="student-id">ID: <%= request.getAttribute("studentId") %></div>
        </div>

        <div class="success">✓ PROFILE SAVED SUCCESSFULLY</div>

        <div class="content">
            <div class="info-box">
                <div class="label">Program</div>
                <div class="value"><%= request.getAttribute("program") %></div>
            </div>

            <div class="info-box">
                <div class="label">Email</div>
                <div class="value"><%= request.getAttribute("email") %></div>
            </div>

            <div class="info-box">
                <div class="label">Hobbies</div>
                <div class="value">
                    <%= request.getAttribute("hobbies") != null && !request.getAttribute("hobbies").toString().isEmpty() 
                        ? request.getAttribute("hobbies") : "Not specified" %>
                </div>
            </div>

            <% 
                String intro = (String) request.getAttribute("introduction");
                if (intro != null && !intro.trim().isEmpty()) {
            %>
            <div class="intro-box">
                <div class="label">About Me</div>
                <div class="value"><%= intro %></div>
            </div>
            <% } %>
        </div>

        <div class="buttons">
            <a href="index.html" class="btn">Add New Profile</a>
            <a href="viewProfiles.jsp" class="btn btn-secondary">View All Profiles</a>
        </div>
    </div>
</body>
</html>