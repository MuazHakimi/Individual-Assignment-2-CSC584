<%@page import="java.sql.*"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>All Student Profiles</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Consolas', 'Courier New', monospace;
            background: #e8e8e8;
            color: #1a1a1a;
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: #fff;
            border: 1px solid #ccc;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        h1 {
            background: #1a1a1a;
            color: #fff;
            padding: 20px;
            margin: 0;
            font-size: 18px;
            text-transform: uppercase;
            letter-spacing: 2px;
            border-bottom: 2px solid #000;
        }
        .search-box {
            background: #f5f5f5;
            padding: 15px 20px;
            border-bottom: 1px solid #ddd;
        }
        .search-box input {
            padding: 8px 12px;
            width: 350px;
            background: #fff;
            border: 1px solid #999;
            color: #1a1a1a;
            font-family: 'Consolas', monospace;
            font-size: 13px;
            margin-right: 10px;
        }
        .search-box input:focus {
            outline: none;
            border-color: #333;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
        }
        .search-box button {
            padding: 8px 20px;
            background: #1a1a1a;
            color: #fff;
            border: none;
            cursor: pointer;
            font-size: 13px;
            font-weight: bold;
            font-family: 'Consolas', monospace;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .search-box button:hover {
            background: #333;
        }
        .clear-btn {
            background: #999 !important;
            color: #fff !important;
            margin-left: 5px;
        }
        .clear-btn:hover {
            background: #777 !important;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th {
            background: #1a1a1a;
            color: #fff;
            padding: 12px;
            text-align: left;
            border-bottom: 2px solid #000;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            color: #333;
            font-size: 13px;
        }
        tr:hover {
            background: #f9f9f9;
        }
        tr:nth-child(even) {
            background: #fafafa;
        }
        tr:nth-child(even):hover {
            background: #f9f9f9;
        }
        .btn {
            background: #1a1a1a;
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            display: inline-block;
            margin: 20px;
            font-weight: bold;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            border: none;
        }
        .btn:hover {
            background: #333;
        }
        .count {
            color: #1a1a1a;
            padding: 15px 20px;
            background: #f5f5f5;
            border-bottom: 1px solid #ddd;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .no-results {
            text-align: center;
            padding: 60px;
            color: #999;
        }
        .no-results h2 {
            color: #666;
            font-size: 16px;
            margin-bottom: 10px;
        }
        .view-btn {
            background: #1a1a1a;
            color: #fff;
            padding: 6px 12px;
            text-decoration: none;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1px;
            display: inline-block;
        }
        .view-btn:hover {
            background: #333;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📚 All Student Profiles</h1>
        
        <!-- Search Box -->
        <div class="search-box">
            <form method="get" action="viewProfiles.jsp">
                <input type="text" name="search" placeholder="Search by name or student ID..." 
                       value="<%= request.getParameter("search") != null ? request.getParameter("search") : "" %>">
                <button type="submit">🔍 Search</button>
                <% if (request.getParameter("search") != null) { %>
                    <a href="viewProfiles.jsp"><button type="button" class="clear-btn">Clear</button></a>
                <% } %>
            </form>
        </div>
        
        <%
            Connection conn = null;
            Statement stmt = null;
            ResultSet rs = null;
            int count = 0;
            String searchQuery = request.getParameter("search");
            
            try {
                // Connect to database
                Class.forName("org.apache.derby.jdbc.ClientDriver");
                conn = DriverManager.getConnection(
                    "jdbc:derby://localhost:1527/studentprofiles", 
                    "dbuser", 
                    "dbpass"
                );
                
                String sql;
                
                // Build SQL based on search
                if (searchQuery != null && !searchQuery.trim().isEmpty()) {
                    sql = "SELECT * FROM profile WHERE " +
                          "LOWER(name) LIKE '%" + searchQuery.toLowerCase() + "%' OR " +
                          "LOWER(student_id) LIKE '%" + searchQuery.toLowerCase() + "%' " +
                          "ORDER BY id DESC";
                } else {
                    sql = "SELECT * FROM profile ORDER BY id DESC";
                }
                
                // Query profiles
                stmt = conn.createStatement();
                rs = stmt.executeQuery(sql);
                
                // Count results
                while (rs.next()) {
                    count++;
                }
                rs.close();
                stmt.close();
                
                // Query again for display
                stmt = conn.createStatement();
                rs = stmt.executeQuery(sql);
        %>
        
        <div class="count">
            <% if (searchQuery != null && !searchQuery.trim().isEmpty()) { %>
                Search Results: <strong><%= count %></strong> profile(s) found for "<%= searchQuery %>"
            <% } else { %>
                Total Profiles: <strong><%= count %></strong>
            <% } %>
        </div>
        
        <% if (count > 0) { %>
        <table>
            <tr>
                <th>Name</th>
                <th>Student ID</th>
                <th>Program</th>
                <th>Email</th>
                <th>Hobbies</th>
                <th>Action</th>
            </tr>
            
            <% 
                while (rs.next()) {
            %>
            <tr>
                <td><%= rs.getString("name") %></td>
                <td><%= rs.getString("student_id") %></td>
                <td><%= rs.getString("program") %></td>
                <td><%= rs.getString("email") %></td>
                <td><%= rs.getString("hobbies") != null ? rs.getString("hobbies") : "-" %></td>
                <td>
                    <a href="displayProfile.jsp?id=<%= rs.getInt("id") %>" class="view-btn">View</a>
                </td>
            </tr>
            <% 
                }
            %>
        </table>
        <% } else { %>
            <div class="no-results">
                <h2>😕 No profiles found</h2>
                <p>Try a different search term or add a new profile.</p>
            </div>
        <% } %>
        
        <%
            } catch (Exception e) {
                out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
                e.printStackTrace();
            } finally {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            }
        %>
        
        <center>
            <a href="index.html" class="btn">Add New Profile</a>
        </center>
    </div>
</body>
</html>